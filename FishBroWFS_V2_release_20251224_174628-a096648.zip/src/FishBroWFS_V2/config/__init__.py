
"""Configuration constants for FishBroWFS_V2."""


