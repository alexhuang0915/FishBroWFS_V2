
"""Schemas for core modules."""


