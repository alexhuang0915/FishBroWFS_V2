
"""Kernel implementations for simulation."""


