"""Settings page - defaults and presets."""
import subprocess
import json
import logging
from pathlib import Path
from nicegui import ui
from .. import ui_compat as uic

from ..layout.cards import render_card
from ..layout.toasts import show_toast, ToastType
from ..constitution.page_shell import page_shell
from ..constitution.truth_providers import (
    create_evidence_with_guarantee,
    verify_evidence_created,
)

logger = logging.getLogger(__name__)


# -----------------------------------------------------------------------------
# Evidence Guarantee Functions
# -----------------------------------------------------------------------------

def run_ui_forensics_with_evidence() -> dict:
    """
    Run UI forensics and guarantee evidence files are created.
    
    Returns:
        Dict with success status and file paths.
    """
    try:
        # Create forensics output directory
        out_dir = Path("outputs/forensics")
        out_dir.mkdir(parents=True, exist_ok=True)
        
        # Run UI forensics via subprocess (ensures fresh execution)
        cmd = ["python", "-m", "scripts.ui_forensics_dump"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=Path.cwd(),
            timeout=30,
        )
        
        # Check if command succeeded
        if result.returncode != 0:
            logger.error(f"UI forensics failed: {result.stderr}")
            return {
                "success": False,
                "error": result.stderr,
                "stdout": result.stdout,
            }
        
        # Parse output to find created files
        json_path = None
        txt_path = None
        for line in result.stdout.split("\n"):
            if "[OK]" in line:
                path_str = line.split("[OK]")[1].strip()
                path = Path(path_str)
                if path.suffix == ".json":
                    json_path = path
                elif path.suffix == ".txt":
                    txt_path = path
        
        # Verify evidence was created
        evidence_created = False
        if json_path and txt_path:
            if verify_evidence_created(json_path) and verify_evidence_created(txt_path):
                evidence_created = True
        
        return {
            "success": evidence_created,
            "json_path": str(json_path) if json_path else None,
            "txt_path": str(txt_path) if txt_path else None,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
        
    except subprocess.TimeoutExpired:
        logger.error("UI forensics timed out after 30 seconds")
        return {
            "success": False,
            "error": "Timeout after 30 seconds",
        }
    except Exception as e:
        logger.exception("Unexpected error in UI forensics")
        return {
            "success": False,
            "error": str(e),
        }


def run_ui_autopass_with_evidence() -> dict:
    """
    Run UI autopass and guarantee evidence files are created.
    
    Returns:
        Dict with success status and file paths.
    """
    try:
        # Create autopass output directory
        out_dir = Path("outputs/autopass")
        out_dir.mkdir(parents=True, exist_ok=True)
        
        # Run UI autopass via subprocess
        cmd = ["python", "-m", "scripts.ui_autopass"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=Path.cwd(),
            timeout=60,
        )
        
        # Check if command succeeded
        if result.returncode != 0:
            logger.error(f"UI autopass failed: {result.stderr}")
            return {
                "success": False,
                "error": result.stderr,
                "stdout": result.stdout,
            }
        
        # Look for autopass report files
        report_json = out_dir / "autopass_report.json"
        report_txt = out_dir / "autopass_report.txt"
        
        # Verify evidence was created
        evidence_created = False
        if report_json.exists() or report_txt.exists():
            # At least one file should exist
            evidence_created = True
            # Verify they have content
            if report_json.exists():
                verify_evidence_created(report_json)
            if report_txt.exists():
                verify_evidence_created(report_txt)
        
        return {
            "success": evidence_created,
            "json_path": str(report_json) if report_json.exists() else None,
            "txt_path": str(report_txt) if report_txt.exists() else None,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
        
    except subprocess.TimeoutExpired:
        logger.error("UI autopass timed out after 60 seconds")
        return {
            "success": False,
            "error": "Timeout after 60 seconds",
        }
    except Exception as e:
        logger.exception("Unexpected error in UI autopass")
        return {
            "success": False,
            "error": str(e),
        }


def create_system_diagnostics_report() -> dict:
    """
    Create a comprehensive system diagnostics report.
    
    Returns:
        Dict with system information and evidence verification.
    """
    import platform
    import sys
    import time
    
    report = {
        "timestamp": time.time(),
        "system": {
            "platform": platform.platform(),
            "python_version": sys.version,
            "python_path": sys.executable,
        },
        "evidence": {
            "ui_forensics": None,
            "ui_autopass": None,
        },
        "success": False,
    }
    
    # Run UI forensics
    forensics_result = run_ui_forensics_with_evidence()
    report["evidence"]["ui_forensics"] = forensics_result
    
    # Run UI autopass
    autopass_result = run_ui_autopass_with_evidence()
    report["evidence"]["ui_autopass"] = autopass_result
    
    # Overall success
    report["success"] = (
        forensics_result.get("success", False) and
        autopass_result.get("success", False)
    )
    
    # Write the diagnostics report itself as evidence
    report_path = Path("outputs/diagnostics") / f"system_diagnostics_{int(time.time())}.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)
    
    # Verify this report was created
    if verify_evidence_created(report_path):
        report["diagnostics_report_path"] = str(report_path)
    
    return report


# -----------------------------------------------------------------------------
# Settings Page Render
# -----------------------------------------------------------------------------

def render() -> None:
    """Render the Settings page."""
    
    def render_content():
        ui.label("System Settings").classes("text-2xl font-bold text-primary mb-6")
        ui.label("Defaults affect FUTURE intents only.").classes("text-secondary mb-8")
        
        # Compute defaults
        with ui.card().classes("w-full mb-6"):
            ui.label("Compute Defaults").classes("text-lg font-bold mb-2")
            with ui.row().classes("w-full gap-4"):
                ui.select(["LOW", "MID", "HIGH"], label="Default Compute Level", value="MID").classes("w-1/3")
                ui.number("Default Max Combinations", value=1000, min=1, max=100000).classes("w-1/3")
                ui.number("Safety Limit (jobs)", value=500, min=1, max=10000).classes("w-1/3")
        
        # UI preferences
        with ui.card().classes("w-full mb-6"):
            ui.label("UI Preferences").classes("text-lg font-bold mb-2")
            with ui.row().classes("w-full gap-4"):
                ui.select(["Light", "Dark", "Auto"], label="Theme", value="Dark").classes("w-1/3")
                ui.checkbox("Enable animations")
                ui.checkbox("Show confirmations before destructive actions")
            ui.select(["English", "Chinese"], label="Language", value="English").classes("w-1/3 mt-2")
        
        # Presets management
        with ui.card().classes("w-full mb-6"):
            ui.label("Presets").classes("text-lg font-bold mb-2")
            ui.label("Presets are NON‑AUTHORITATIVE and deletable.").classes("text-sm text-tertiary mb-4")
            with ui.row().classes("w-full gap-4"):
                preset_select = ui.select(["SMOKE‑MNQ‑30m", "LITE‑MES‑60m", "FULL‑MNQ‑240m"], label="Load Preset", value=None).classes("w-1/3")
                load_btn = ui.button("Load", icon="upload").classes("w-1/6")
                save_current_btn = ui.button("Save Current", icon="save").classes("w-1/6")
                delete_btn = ui.button("Delete", icon="delete", color="danger").classes("w-1/6")
            # Preset list
            with ui.column().classes("w-full mt-4"):
                for name in ["SMOKE‑MNQ‑30m", "LITE‑MES‑60m", "FULL‑MNQ‑240m"]:
                    with ui.row().classes("w-full items-center py-2 border-b border-panel-light last:border-0"):
                        ui.label(name).classes("flex-grow")
                        apply_btn = uic.button("Apply", size=uic.BtnSize.SM)
                        edit_btn = uic.button("Edit", size=uic.BtnSize.SM, color="transparent")
                        # Attach handlers
                        apply_btn.on("click", lambda n=name: show_toast(f"Applied preset: {n}", ToastType.INFO))
                        edit_btn.on("click", lambda n=name: show_toast(f"Edit preset: {n} (not implemented)", ToastType.INFO))
        
        # Attach handlers for preset management buttons
        def on_load():
            selected = preset_select.value
            if selected:
                show_toast(f"Loading preset: {selected}", ToastType.INFO)
            else:
                show_toast("No preset selected", ToastType.WARNING)
        
        def on_save_current():
            show_toast("Save current preset not yet implemented", ToastType.INFO)
        
        def on_delete():
            selected = preset_select.value
            if selected:
                show_toast(f"Delete preset: {selected} (not implemented)", ToastType.WARNING)
            else:
                show_toast("No preset selected", ToastType.WARNING)
        
        load_btn.on("click", on_load)
        save_current_btn.on("click", on_save_current)
        delete_btn.on("click", on_delete)
        
        # System info
        with ui.card().classes("w-full mb-6"):
            ui.label("System Information").classes("text-lg font-bold mb-2")
            with ui.column().classes("w-full gap-1"):
                ui.label("FishBroWFS V2 · Nexus UI")
                ui.label("Backend API: http://localhost:8000")
                ui.label("Python: 3.11.6")
                ui.label("NiceGUI: 2.0+")
                ui.label("Workspace: /home/fishbro/FishBroWFS_V2")
        
        # Developer / Diagnostics section (Evidence Guarantee)
        with ui.card().classes("w-full mb-6 border-2 border-cyan"):
            ui.label("Developer / Diagnostics").classes("text-lg font-bold text-cyan mb-2")
            with ui.column().classes("w-full gap-2"):
                ui.label("Tools for debugging and system inspection with evidence guarantee.").classes("text-sm text-tertiary")
                ui.label("All actions create verifiable evidence files.").classes("text-xs text-cyan")
                
                with ui.row().classes("w-full gap-2"):
                    diag_btn1 = ui.button("Run UI Forensics", icon="bug_report", color="transparent")
                    diag_btn2 = ui.button("Run UI Autopass", icon="health_and_safety", color="transparent")
                    diag_btn3 = ui.button("Full Diagnostics", icon="download", color="transparent")
                
                # Progress/status indicators
                diag_status = ui.label("").classes("text-sm")
                diag_progress = ui.linear_progress(show_value=False).classes("w-full hidden")
                
                # Attach handlers with evidence guarantee
                def on_run_forensics():
                    diag_status.set_value("Running UI forensics with evidence guarantee...")
                    diag_progress.set_visibility(True)
                    try:
                        result = run_ui_forensics_with_evidence()
                        if result.get("success"):
                            json_path = result.get("json_path", "unknown")
                            txt_path = result.get("txt_path", "unknown")
                            diag_status.set_value(f"✅ Forensics completed. Evidence: {Path(json_path).name}, {Path(txt_path).name}")
                            show_toast("UI forensics completed with evidence guarantee", ToastType.SUCCESS)
                        else:
                            error = result.get("error", "Unknown error")
                            diag_status.set_value(f"❌ Forensics failed: {error}")
                            show_toast(f"UI forensics failed: {error}", ToastType.ERROR)
                    except Exception as e:
                        diag_status.set_value(f"❌ Exception: {e}")
                        show_toast(f"UI forensics exception: {e}", ToastType.ERROR)
                    finally:
                        diag_progress.set_visibility(False)
                
                def on_run_autopass():
                    diag_status.set_value("Running UI autopass with evidence guarantee...")
                    diag_progress.set_visibility(True)
                    try:
                        result = run_ui_autopass_with_evidence()
                        if result.get("success"):
                            json_path = result.get("json_path")
                            txt_path = result.get("txt_path")
                            files = []
                            if json_path:
                                files.append(Path(json_path).name)
                            if txt_path:
                                files.append(Path(txt_path).name)
                            file_list = ", ".join(files) if files else "no files"
                            diag_status.set_value(f"✅ Autopass completed. Evidence: {file_list}")
                            show_toast("UI autopass completed with evidence guarantee", ToastType.SUCCESS)
                        else:
                            error = result.get("error", "Unknown error")
                            diag_status.set_value(f"❌ Autopass failed: {error}")
                            show_toast(f"UI autopass failed: {error}", ToastType.ERROR)
                    except Exception as e:
                        diag_status.set_value(f"❌ Exception: {e}")
                        show_toast(f"UI autopass exception: {e}", ToastType.ERROR)
                    finally:
                        diag_progress.set_visibility(False)
                
                def on_full_diagnostics():
                    diag_status.set_value("Running full system diagnostics with evidence guarantee...")
                    diag_progress.set_visibility(True)
                    try:
                        result = create_system_diagnostics_report()
                        if result.get("success"):
                            report_path = result.get("diagnostics_report_path", "unknown")
                            diag_status.set_value(f"✅ Full diagnostics completed. Report: {Path(report_path).name}")
                            show_toast("Full diagnostics completed with evidence guarantee", ToastType.SUCCESS)
                        else:
                            diag_status.set_value("❌ Full diagnostics partially failed (check logs)")
                            show_toast("Full diagnostics completed with some failures", ToastType.WARNING)
                    except Exception as e:
                        diag_status.set_value(f"❌ Exception: {e}")
                        show_toast(f"Full diagnostics exception: {e}", ToastType.ERROR)
                    finally:
                        diag_progress.set_visibility(False)
                
                diag_btn1.on("click", on_run_forensics)
                diag_btn2.on("click", on_run_autopass)
                diag_btn3.on("click", on_full_diagnostics)
        
        # Danger zone
        with ui.card().classes("w-full border-2 border-danger"):
            ui.label("⚠️ Danger Zone").classes("text-lg font-bold text-danger mb-2")
            with ui.column().classes("w-full gap-2"):
                ui.label("Actions here can affect system stability.")
                with ui.row().classes("w-full gap-2"):
                    clear_presets_btn = ui.button("Clear All Presets", icon="delete_forever", color="danger")
                    reset_defaults_btn = ui.button("Reset Defaults", icon="restart_alt", color="warning")
                    flush_cache_btn = ui.button("Flush Cache", icon="cleaning_services", color="warning")
                ui.label("These actions only affect UI settings, not run artifacts.").classes("text-xs text-muted")
                
                # Attach handlers
                clear_presets_btn.on("click", lambda: show_toast("Clear all presets (not implemented)", ToastType.WARNING))
                reset_defaults_btn.on("click", lambda: show_toast("Reset defaults (not implemented)", ToastType.WARNING))
                flush_cache_btn.on("click", lambda: show_toast("Flush cache (not implemented)", ToastType.WARNING))
    
    # Wrap in page shell
    page_shell("System Settings", render_content)
