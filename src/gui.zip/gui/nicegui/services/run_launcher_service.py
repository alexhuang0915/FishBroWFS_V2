#!/usr/bin/env python3
"""
Run Launcher Service – launch a local run (offline‑capable).

This service creates a run directory, writes intent.json, derives derived.json,
and optionally creates a placeholder manifest. It works without backend connectivity.
"""

import json
import logging
import uuid
from pathlib import Path
from typing import Optional, Dict, Any

from ..models.intent_models import IntentDocument
from ..models.derived_models import DerivedDocument
from .intent_service import write_intent
from .derive_service import derive_from_intent, write_derived

logger = logging.getLogger(__name__)


def launch_run(
    intent: IntentDocument,
    outputs_root: Path = Path("outputs"),
    season: Optional[str] = None,
    run_id: Optional[str] = None,
    skip_derive: bool = False,
) -> Path:
    """
    Launch a new run (offline‑capable).
    
    Steps:
        1. Determine season and generate run_id if not provided.
        2. Write intent.json using intent_service.
        3. Derive derived.json using derive_service (unless skip_derive).
        4. Create a minimal manifest.json placeholder.
        5. Return the run directory path.
    
    Args:
        intent: Validated intent document.
        outputs_root: Root outputs directory.
        season: Season identifier; defaults to intent.identity.season.
        run_id: Run identifier; defaults to a generated UUID‑based ID.
        skip_derive: If True, skip derived.json creation (for testing).
    
    Returns:
        Path to the created run directory.
    
    Raises:
        ValueError: If intent validation fails.
        IOError: If directory creation or file writing fails.
    """
    if season is None:
        season = intent.identity.season
    if run_id is None:
        # Generate a deterministic but unique run ID
        import hashlib
        import time
        seed = f"{season}_{intent.identity.run_mode}_{time.time()}"
        run_id = f"run_{hashlib.sha256(seed.encode()).hexdigest()[:8]}"
    
    # 1. Write intent.json (intent_service already does this)
    intent_path = write_intent(intent, outputs_root=outputs_root, season=season, run_id=run_id)
    run_dir = intent_path.parent
    logger.info(f"Intent written to {intent_path}")
    
    # 2. Derive derived.json
    derived_path = None
    if not skip_derive:
        try:
            derived = derive_from_intent(intent)
            derived_path = write_derived(derived, outputs_root=outputs_root, season=season, run_id=run_id)
            logger.info(f"Derived written to {derived_path}")
        except Exception as e:
            logger.warning(f"Derivation failed (run will continue): {e}")
            # Continue without derived.json
    
    # 3. Create a minimal manifest.json placeholder
    manifest_path = run_dir / "manifest.json"
    if not manifest_path.exists():
        manifest = {
            "version": "1.0",
            "run_id": run_id,
            "season": season,
            "status": "CREATED",
            "created_at": intent_path.stat().st_mtime,
            "artifacts": {
                "intent": intent_path.name,
                "derived": derived_path.name if derived_path else None,
            },
            "notes": "Run created by offline launcher",
        }
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)
        logger.info(f"Manifest placeholder written to {manifest_path}")
    
    # 4. Create a simple log file
    log_path = run_dir / "launch.log"
    if not log_path.exists():
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(f"Run {run_id} launched at {intent_path.stat().st_mtime}\n")
    
    return run_dir


def launch_run_from_dict(
    intent_dict: Dict[str, Any],
    outputs_root: Path = Path("outputs"),
    season: Optional[str] = None,
    run_id: Optional[str] = None,
    skip_derive: bool = False,
) -> Optional[Path]:
    """
    Convenience wrapper that validates intent dict and launches a run.
    
    Returns:
        Run directory path on success, None on validation failure.
    """
    try:
        intent = IntentDocument.model_validate(intent_dict)
        return launch_run(intent, outputs_root, season, run_id, skip_derive)
    except Exception as e:
        logger.error(f"Intent validation failed: {e}")
        return None


def get_run_status(run_dir: Path) -> Dict[str, Any]:
    """
    Get status of a local run (offline).
    
    Returns a dict with keys:
        - run_id
        - season
        - status (CREATED, RUNNING, COMPLETED, FAILED)
        - artifacts present (intent, derived, manifest, logs)
        - start_time
        - duration
    """
    run_id = run_dir.name
    season = run_dir.parent.parent.name if run_dir.parent.parent.name == "seasons" else "unknown"
    
    intent_exists = (run_dir / "intent.json").exists()
    derived_exists = (run_dir / "derived.json").exists()
    manifest_exists = (run_dir / "manifest.json").exists()
    logs_exist = (run_dir / "launch.log").exists()
    
    # Determine status based on artifacts
    if manifest_exists:
        status = "COMPLETED"
    elif derived_exists:
        status = "RUNNING"
    elif intent_exists:
        status = "CREATED"
    else:
        status = "UNKNOWN"
    
    # Start time from directory mtime
    start_time = run_dir.stat().st_mtime if intent_exists else None
    
    return {
        "run_id": run_id,
        "season": season,
        "status": status,
        "artifacts": {
            "intent": intent_exists,
            "derived": derived_exists,
            "manifest": manifest_exists,
            "logs": logs_exist,
        },
        "start_time": start_time,
        "duration": None,  # could compute if completed
        "path": str(run_dir),
    }


def list_local_runs(outputs_root: Path = Path("outputs"), season: str = "2026Q1") -> list[Dict[str, Any]]:
    """
    List all local runs for a given season (offline).
    
    This is a thin wrapper around run_index_service.list_runs.
    """
    from .run_index_service import list_runs
    return list_runs(outputs_root=outputs_root, season=season)


if __name__ == "__main__":
    # Simple CLI for testing
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        # Create a dummy intent
        from ..models.intent_models import (
            IntentDocument, IntentIdentity, MarketUniverse,
            StrategySpace, ComputeIntent, ProductRiskAssumptions,
            RunMode, ComputeLevel
        )
        identity = IntentIdentity(season="2026Q1", run_mode=RunMode.SMOKE)
        market_universe = MarketUniverse(instrument="MNQ", timeframe="60m", regime_filters=[])
        strategy_space = StrategySpace(long=["S1"], short=[])
        compute_intent = ComputeIntent(compute_level=ComputeLevel.LOW, max_combinations=100)
        product_risk_assumptions = ProductRiskAssumptions(
            margin_model="symbolic",
            contract_specs={},
            risk_budget="medium"
        )
        intent = IntentDocument(
            identity=identity,
            market_universe=market_universe,
            strategy_space=strategy_space,
            compute_intent=compute_intent,
            product_risk_assumptions=product_risk_assumptions,
        )
        run_dir = launch_run(intent, skip_derive=False)
        print(f"Run launched: {run_dir}")
        status = get_run_status(run_dir)
        print(json.dumps(status, indent=2))
    else:
        print("Usage: python -m gui.nicegui.services.run_launcher_service test")